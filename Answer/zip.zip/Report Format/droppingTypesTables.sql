DROP TABLE MS_CustomerAccount_Table;
DROP TYPE MS_CustomerAccount_Type FORCE;

DROP TABLE MS_Employee_Table;
DROP TYPE MS_Employee_Type FORCE;

DROP TABLE MS_Customer_Table;
DROP TYPE MS_Customer_Type FORCE;

DROP TABLE MS_Account_Table;
DROP TYPE MS_Account_Type FORCE;

DROP TABLE MS_Branch_Table;
DROP TYPE MS_Branch_Type FORCE;

DROP TABLE MS_Job_Table;
DROP TYPE MS_Job_Type FORCE;

DROP TYPE MS_Person_Type FORCE;
DROP TYPE MS_Name_Type FORCE;
DROP TYPE MS_Phone_Type FORCE;
DROP TYPE MS_Mobile_Nested FORCE;
DROP TYPE MS_Address_Type FORCE;
DROP TYPE MS_Mobile_Nested FORCE;